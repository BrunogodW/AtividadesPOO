package atv4;

public class Calculadora {
    private double numero;
    
    public Calculadora(){
        numero = 0;
    }

    public double getNumero() {
        return numero;
    }

    public void setNumero(double numero) {
        this.numero = numero;
    }
    
    public double somar(double numeroCalc){
        return this.numero + numeroCalc;
    }
    public double subtrair(double numeroCalc){
        return this.numero - numeroCalc;
    }
    public double multiplicar(double numeroCalc){
        return this.numero * numeroCalc;
    }
    public String dividir(double numeroCalc){
        if(numeroCalc != 0){
        return ( this.numero / numeroCalc + "");
    } else{
            return "Infinito";
        }
    }
    public double calcularRaiz(){
        return Math.sqrt(this.numero);
    }
    public double potenciar(double numeroCalc){
        return Math.pow(this.numero, numeroCalc);
    }
    public double calcularFatorial(){
        
        for(double fator = this.numero -1; fator > 1; fator--){
            numero *= fator;
        }
        return numero;
    }
}
