package atv4;

import java.util.Scanner;


public class Atv4 {

   
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Calculadora calc1 = new Calculadora();
        System.out.println("Insira um número: ");
        calc1.setNumero(ler.nextDouble());
        System.out.println("1-Adição");
        System.out.println("2-Subtração");
        System.out.println("3-Multiplicação");
        System.out.println("4-Divisão");
        System.out.println("5-Raiz quadrada");
        System.out.println("6-Potência");
        System.out.println("7-Fatorial");
        int opc = ler.nextInt();
        switch(opc){
            case 1:
                System.out.println("Insira um número para somar: ");
                System.out.println("O resultado é " + calc1.somar(ler.nextDouble()));
                
                break;
            case 2:
                System.out.println("Insira um número para subtrair: ");
                System.out.println("O resultado é " + calc1.subtrair(ler.nextDouble()));
                break;
            case 3:
                System.out.println("Insira um número para multiplicar: ");
                System.out.println("O resultado é " + calc1.multiplicar(ler.nextDouble()));
                break;
            case 4:
                System.out.println("Insira um número para dividir: ");
                System.out.println("O resultado é " + calc1.dividir(ler.nextDouble()));
                break;
            case 5:
                System.out.println("O resultado é " + calc1.calcularRaiz());
                break;
            case 6:
                System.out.println("Insira um número para potenciar: ");
                System.out.println("O resultado é " + calc1.potenciar(ler.nextDouble()));
                break;
            case 7:
                System.out.println("O resultado é " + calc1.calcularFatorial());
                break;
            default:
                System.out.println("Opção inválida");
                break;
        }
        
    }
    
}
