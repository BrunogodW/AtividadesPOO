package atv8;

import java.util.Scanner;

public class Atv8 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Funcionario func1 = new Funcionario();
        System.out.println("Insira o nome: ");
        func1.setNome(ler.nextLine());
        System.out.println("Insira o salário: ");
        func1.setSalario(ler.nextDouble());
        System.out.println("Insira um reajuste salarial(em %): ");
        func1.ajustarSalario(ler.nextDouble());
        func1.mostrarInfo();
    }

}
