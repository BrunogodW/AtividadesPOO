package atv8;

public class Funcionario {
    private String nome;
    private double salario;

    public Funcionario(){
        nome = "";
        salario = 0;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public void ajustarSalario(double ajuste){
        setSalario(((this.salario * ajuste) / 100)+this.salario);
    }
    public void mostrarInfo(){
        System.out.println("Nome: "+this.nome);
        System.out.println("Salário: "+this.salario);
    }
    public void calcularValorAnual(double salario){
        this.salario = salario * 13;
    }
}
