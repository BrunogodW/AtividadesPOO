
package atv5;

public class ContaBancaria {
    private String titular;
    private double saldo;
    
    public ContaBancaria(){
        titular = "";
        saldo = 0;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public void depositar(double deposito){
        this.saldo += deposito;
    }
    
    public void sacar(double saque){
        if(saque <= this.saldo){
            this.saldo -= saque;
        } else{
            System.out.println("Saldo insuficiente");
        }
    }
    public void exibirSaldo(){
        System.out.println("Saldo: " + this.saldo);
    }
    public double calcularRendimento(){
        return 0.05 * this.saldo;
    }
    
}
