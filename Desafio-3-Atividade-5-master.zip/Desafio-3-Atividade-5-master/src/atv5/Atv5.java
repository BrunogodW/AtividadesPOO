package atv5;

import java.util.Scanner;

public class Atv5 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        ContaBancaria cont1 = new ContaBancaria();
        System.out.println("Titular da conta: ");
        cont1.setTitular(ler.nextLine());
        System.out.println("Saldo: ");
        cont1.setSaldo(ler.nextDouble());
        System.out.println("Depósito: ");
        cont1.depositar(ler.nextDouble());
        System.out.println("Saque: ");
        cont1.sacar(ler.nextDouble());

        cont1.exibirSaldo();
    }

}
