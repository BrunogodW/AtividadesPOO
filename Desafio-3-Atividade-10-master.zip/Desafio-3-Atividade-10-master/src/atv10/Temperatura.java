package atv10;

public class Temperatura {
    private double celsius;

    public Temperatura(){
        celsius = 0;
    }
    
    public double getCelsius() {
        return celsius;
    }

    public void setCalsius(double celsius) {
        this.celsius = celsius;
    }
    
    public double toFahrenheit(double celsius){
        return (celsius * 2) + 30;
    }
    public double toKelvin(double celsius){
        return celsius + 273.15;
    }
    public void mostrarInfo(){
        System.out.println("Celsius: "+this.celsius);
        System.out.println("Fahrenheit: "+this.toFahrenheit(celsius));
        System.out.println("Kelvin: "+this.toKelvin(celsius));
    }
    
}
