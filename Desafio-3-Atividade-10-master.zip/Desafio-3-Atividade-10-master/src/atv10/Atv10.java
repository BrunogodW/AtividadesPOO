
package atv10;

import java.util.Scanner;


public class Atv10 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Temperatura temp = new Temperatura();
        System.out.println("Insira uma temperatura em celsius");
        temp.setCalsius(ler.nextDouble());
        temp.mostrarInfo();
    }
    
}
