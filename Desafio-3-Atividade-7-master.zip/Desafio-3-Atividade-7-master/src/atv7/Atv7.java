/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atv7;

import java.util.Scanner;

/**
 *
 * @author vdasi
 */
public class Atv7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            Scanner ler = new Scanner(System.in);
            Carro car1 = new Carro();
            System.out.println("Modelo do carro: ");
            car1.setModelo(ler.nextLine());
            System.out.println("Consumo de litros por KM: ");
            car1.setConsumoPorKm(ler.nextDouble());
            System.out.println("Distância da viagem: ");
            car1.setDistancia(ler.nextDouble());
            System.out.println("Preço do combustivel: ");
            car1.setPrecoCombustivel(ler.nextDouble());
            
            System.out.println("Modelo: "+ car1.getModelo());
            System.out.println("Consumo por KM: " + car1.getConsumoPorKm());
            System.out.println("Consumo da viagem: " + car1.calcularConsumo(car1.getDistancia()));
            System.out.println("Custo da viagem: " + car1.calcularCusto(car1.getPrecoCombustivel()));
            
    }

}
