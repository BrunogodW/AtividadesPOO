package atv7;

public class Carro {

    private String modelo;
    private double consumoPorKm;
    private double distancia;
    private double precoCombustivel;

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }

    public double getPrecoCombustivel() {
        return precoCombustivel;
    }

    public void setPrecoCombustivel(double precoCombustivel) {
        this.precoCombustivel = precoCombustivel;
    }

    public Carro() {
        modelo = "";
        consumoPorKm = 0;
        distancia = 0;
        precoCombustivel = 0;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getConsumoPorKm() {
        return consumoPorKm;
    }

    public void setConsumoPorKm(double consumoPorKm) {
        this.consumoPorKm = consumoPorKm;
    }

    public double calcularConsumo(double distancia) {
        return distancia / this.consumoPorKm;
    }

    public double calcularCusto(double precoCombustivel) {
        return calcularConsumo(this.distancia) * precoCombustivel;
    }

}
