package atv3;

public class Produto {

    private String nome;
    private int quantidade;
    private double preco;

    public Produto() {
        nome = "";
        quantidade = 0;
        preco = 0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void removerDoEstoque(int nRemover) {
        if (nRemover <= this.quantidade) {
            this.quantidade -= nRemover;
        } else {
            System.out.println("Quantidade insuficiente");
        }
    }

    public void adicionarAoEstoque(int nAdicionar) {
        this.quantidade += nAdicionar;
    }

    public double calcularValorEstoque() {
        return this.quantidade * this.preco;
    }

    public void mostrarInfo() {
        System.out.println("Nome: " + this.nome);
        System.out.println("Quantidade: " + this.quantidade);
        System.out.println("Valor em estoque: R$" + calcularValorEstoque());
    }
}
