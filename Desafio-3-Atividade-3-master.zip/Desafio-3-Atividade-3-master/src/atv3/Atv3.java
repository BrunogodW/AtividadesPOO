package atv3;

import java.util.Scanner;

public class Atv3 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Produto prod1 = new Produto();
        System.out.println("Nome do produto: ");
        prod1.setNome(ler.nextLine());
        System.out.println("Quantidade do produto: ");
        prod1.setQuantidade(ler.nextInt());
        System.out.println("Preço do produto: ");
        prod1.setPreco(ler.nextDouble());
        System.out.println("Adicionar número de produtos ao estoque: ");
        prod1.adicionarAoEstoque(ler.nextInt());
        System.out.println("Remover número de produtos do estoque: ");
        prod1.removerDoEstoque(ler.nextInt());

        prod1.mostrarInfo();
    }

}
