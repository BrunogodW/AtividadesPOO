/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atv6;

import java.util.Scanner;

/**
 *
 * @author vdasi
 */
public class Atv6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner ler = new Scanner(System.in);
       Aluno aluno1 = new Aluno();
       System.out.println("Insira seu nome:");
       aluno1.setNome(ler.nextLine());
       System.out.println("Insira a primeira nota: ");
       aluno1.setNota1(ler.nextDouble());
       System.out.println("Insira a segunda nota: ");
       aluno1.setNota2(ler.nextDouble());
       aluno1.mostrarInfo();
    }
    
}
