package atv2;

import java.util.Scanner;

public class Atv2 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Pessoa pessoa1 = new Pessoa();
        System.out.println("Nome: ");
        pessoa1.setNome(ler.nextLine());
        System.out.println("Idade: ");
        pessoa1.setIdade(ler.nextInt());
        System.out.println("Altura: ");
        pessoa1.setAltura(ler.nextDouble());
        pessoa1.mostrarInfo();
        System.out.println(pessoa1.verificarMaiorIdade(pessoa1.getIdade()));
        System.out.println(pessoa1.calcularAte100(pessoa1.getIdade()));
    }

}
