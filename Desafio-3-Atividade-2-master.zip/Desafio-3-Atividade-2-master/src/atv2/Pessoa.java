package atv2;

public class Pessoa {

    private String nome;
    private int idade;
    private double altura;

    public Pessoa() {
        nome = "";
        idade = 0;
        altura = 0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public void mostrarInfo() {
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.idade);
        System.out.println("Altura: " + this.altura);
    }

    public String verificarMaiorIdade(int idade) {
        if (idade >= 18) {
            return "Maior de idade";
        } else {
            return "Menor de idade";
        }

    }

    public String calcularAte100(int idade) {
        return "Falta " + (100 - idade) + " anos até os 100";
    }
}
