package atv1;

import java.util.Scanner;

public class Atv1 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Palavra palavra1 = new Palavra();
        System.out.println("Insira uma palavra: ");
        palavra1.setPalavra(ler.nextLine());
        System.out.println("A palavra tem " + palavra1.calcularCaracteres(palavra1.getPalavra()) + " caracteres");
        System.out.println(palavra1.verificarParOuImpar());
        System.out.println(palavra1.inverterPalavra());
    }

}
