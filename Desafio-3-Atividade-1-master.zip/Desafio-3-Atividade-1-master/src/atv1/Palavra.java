package atv1;

public class Palavra {
    private String palavra;
    
    public Palavra(){
        palavra = "";
    }

    public String getPalavra() {
        return palavra;
    }

    public void setPalavra(String palavra) {
        this.palavra = palavra;
    }
    
    public int calcularCaracteres(String palavra){
        return palavra.length();
    }
    public String verificarParOuImpar(){
        if(calcularCaracteres(palavra)% 2 == 0){
            return "Par";
        } else{
            return "Ímpar";
        }
    }
    public String inverterPalavra() {
        String invertida = "";
        for (int i = palavra.length() - 1; i >= 0; i--) {
            invertida += palavra.charAt(i);
        }
        return invertida;
    }
}
